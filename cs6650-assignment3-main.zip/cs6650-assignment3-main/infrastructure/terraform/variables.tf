variable "project_name" {
  description = "Project name prefix for all AWS resources."
  type        = string
  default     = "cs6650-a3"
}

variable "aws_region" {
  description = "AWS region."
  type        = string
  default     = "us-west-2"
}

variable "vpc_cidr" {
  description = "CIDR block for the VPC."
  type        = string
  default     = "10.20.0.0/16"
}

variable "public_subnet_cidrs" {
  description = "Two public subnet CIDRs for ALB and ECS tasks."
  type        = list(string)
  default     = ["10.20.1.0/24", "10.20.2.0/24"]
}

variable "availability_zones" {
  description = "Availability Zones aligned with public_subnet_cidrs."
  type        = list(string)
  default     = ["us-west-2a", "us-west-2b"]
}

variable "admin_cidr" {
  description = "CIDR allowed to access RabbitMQ Management UI (15672)."
  type        = string
  default     = "0.0.0.0/0"
}

variable "existing_ecs_task_execution_role_arn" {
  description = "Existing IAM role ARN used as ECS task execution role (Learner Lab compatible)."
  type        = string
  default     = ""
}

variable "existing_ecs_task_role_arn" {
  description = "Existing IAM role ARN used as ECS task role (Learner Lab compatible)."
  type        = string
  default     = ""
}

variable "shopping_cart_image" {
  description = "ECR image URI for shopping-cart-service."
  type        = string
}

variable "credit_card_image" {
  description = "ECR image URI for credit-card-authorizer."
  type        = string
}

variable "product_image" {
  description = "ECR image URI for the good product service."
  type        = string
}

variable "bad_product_image" {
  description = "ECR image URI for the bad-product-service."
  type        = string
}

variable "warehouse_image" {
  description = "ECR image URI for warehouse-consumer."
  type        = string
}

variable "rabbitmq_image" {
  description = "Container image for RabbitMQ (for example rabbitmq:3-management)."
  type        = string
  default     = "rabbitmq:3.13-management-alpine"
}

variable "shopping_cart_cpu" {
  description = "CPU units for shopping-cart-service task."
  type        = number
  default     = 512
}

variable "shopping_cart_memory" {
  description = "Memory (MiB) for shopping-cart-service task."
  type        = number
  default     = 1024
}

variable "credit_card_cpu" {
  description = "CPU units for credit-card-authorizer task."
  type        = number
  default     = 512
}

variable "credit_card_memory" {
  description = "Memory (MiB) for credit-card-authorizer task."
  type        = number
  default     = 1024
}

variable "product_cpu" {
  description = "CPU units for product/bad-product tasks."
  type        = number
  default     = 512
}

variable "product_memory" {
  description = "Memory (MiB) for product/bad-product tasks."
  type        = number
  default     = 1024
}

variable "warehouse_cpu" {
  description = "CPU units for warehouse-consumer task."
  type        = number
  default     = 512
}

variable "warehouse_memory" {
  description = "Memory (MiB) for warehouse-consumer task."
  type        = number
  default     = 1024
}

variable "rabbitmq_cpu" {
  description = "CPU units for RabbitMQ task."
  type        = number
  default     = 512
}

variable "rabbitmq_memory" {
  description = "Memory (MiB) for RabbitMQ task."
  type        = number
  default     = 1024
}
