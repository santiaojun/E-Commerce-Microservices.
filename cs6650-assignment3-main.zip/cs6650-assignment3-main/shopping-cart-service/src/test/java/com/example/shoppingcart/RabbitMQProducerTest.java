package com.example.shoppingcart;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class RabbitMQProducerTest {

    private RecordingRabbitTemplate rabbitTemplate;
    private RabbitMQProducer producer;

    @BeforeEach
    void setUp() {
        rabbitTemplate = new RecordingRabbitTemplate();
        producer = new RabbitMQProducer(rabbitTemplate, "warehouse_queue");
    }

    @Test
    void initRegistersConfirmAndReturnsCallbacks() {
        producer.init();

        assertTrue(rabbitTemplate.confirmCallbackSet);
        assertTrue(rabbitTemplate.returnsCallbackSet);
    }

    @Test
    void sendOrderPublishesToConfiguredQueueWithCorrelationId() {
        String payload = "{\"order_id\":\"abc-123\"}";

        producer.sendOrder(payload);

        assertEquals("", rabbitTemplate.exchange);
        assertEquals("warehouse_queue", rabbitTemplate.routingKey);
        assertEquals(payload, rabbitTemplate.message);
        assertNotNull(rabbitTemplate.correlationData);
        assertNotNull(rabbitTemplate.correlationData.getId());
        assertFalse(rabbitTemplate.correlationData.getId().isBlank());
    }

    private static class RecordingRabbitTemplate extends RabbitTemplate {
        private boolean confirmCallbackSet;
        private boolean returnsCallbackSet;
        private String exchange;
        private String routingKey;
        private Object message;
        private CorrelationData correlationData;

        @Override
        public void setConfirmCallback(ConfirmCallback confirmCallback) {
            this.confirmCallbackSet = confirmCallback != null;
        }

        @Override
        public void setReturnsCallback(ReturnsCallback returnCallback) {
            this.returnsCallbackSet = returnCallback != null;
        }

        @Override
        public void convertAndSend(
                String exchange,
                String routingKey,
                Object object,
                CorrelationData correlationData) {
            this.exchange = exchange;
            this.routingKey = routingKey;
            this.message = object;
            this.correlationData = correlationData;
        }
    }
}
