package com.example.shoppingcart;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;
import java.util.UUID;

@Component
public class RabbitMQProducer {

    private static final Logger log = LoggerFactory.getLogger(RabbitMQProducer.class);

    private final RabbitTemplate rabbitTemplate;
    private final String queueName;

    public RabbitMQProducer(
            RabbitTemplate rabbitTemplate,
            @Value("${rabbitmq.queue:warehouse_queue}") String queueName) {
        this.rabbitTemplate = rabbitTemplate;
        this.queueName = queueName;
    }

    @PostConstruct
    public void init() {
        rabbitTemplate.setConfirmCallback((correlationData, ack, cause) -> {
            if (ack) {
                log.info("Message confirmed by broker. ID={}",
                        correlationData != null ? correlationData.getId() : "");
            } else {
                log.error("Message not delivered. Cause={}", cause);
            }
        });

        rabbitTemplate.setReturnsCallback(returned -> {
            log.error("Message returned. ReplyCode={}, ReplyText={}, RoutingKey={}, Message={}",
                    returned.getReplyCode(),
                    returned.getReplyText(),
                    returned.getRoutingKey(),
                    new String(returned.getMessage().getBody()));
        });
    }

    public void sendOrder(String message) {

        CorrelationData correlationData =
                new CorrelationData(UUID.randomUUID().toString());

        rabbitTemplate.convertAndSend(
                "",
                queueName,
                message,
                correlationData
        );

        log.info("Sent message to queue '{}': {}", queueName, message);
    }
}
