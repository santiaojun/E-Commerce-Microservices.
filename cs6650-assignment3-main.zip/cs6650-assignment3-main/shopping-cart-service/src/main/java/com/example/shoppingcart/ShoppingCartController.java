package com.example.shoppingcart;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/shopping-carts")
public class ShoppingCartController {

    private final Map<String, Cart> cartDB = new HashMap<>();
    private final RabbitMQProducer producer;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public ShoppingCartController(RabbitMQProducer producer) {
        this.producer = producer;
    }

    // ✅ 1. Create Cart
    @PostMapping
    public ResponseEntity<Cart> createCart(@RequestParam String customer_id) {

        String cartId = UUID.randomUUID().toString();
        Cart cart = new Cart(cartId);
        cartDB.put(cartId, cart);

        return ResponseEntity.ok(cart);
    }

    // ✅ 2. Add Item
    @PostMapping("/{cartId}/addItem")
    public ResponseEntity<?> addItem(
            @PathVariable String cartId,
            @RequestParam String product_id,
            @RequestParam int quantity) {

        Cart cart = cartDB.get(cartId);

        if (cart == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Cart not found");
        }

        cart.addItem(product_id, quantity);
        return ResponseEntity.ok(cart);
    }

    // ✅ 3. Get Cart
    @GetMapping("/{cartId}")
    public ResponseEntity<?> getCart(@PathVariable String cartId) {

        Cart cart = cartDB.get(cartId);

        if (cart == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Cart not found");
        }

        return ResponseEntity.ok(cart);
    }

    // ✅ 4. Checkout
    @PostMapping("/{cartId}/checkout")
    public ResponseEntity<?> checkout(
            @PathVariable String cartId,
            @RequestParam String credit_card_number) {

        Cart cart = cartDB.get(cartId);

        if (cart == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Cart not found");
        }

        // ✅ Step 1:call CCA
        boolean authorized = callCCA(credit_card_number);

        if (!authorized) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Payment failed");
        }

        try {
            // ✅ Step 2: JSON
            Map<String, Object> order = new HashMap<>();
            order.put("order_id", cartId);

            List<Map<String, Object>> items = new ArrayList<>();

            for (Map.Entry<String, Integer> entry : cart.getItems().entrySet()) {
                Map<String, Object> item = new HashMap<>();
                item.put("product_id", entry.getKey());
                item.put("quantity", entry.getValue());
                items.add(item);
            }

            order.put("items", items);

            String message = objectMapper.writeValueAsString(order);

            // ✅ Step 3: sned RabbitMQ
            producer.sendOrder(message);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to process order");
        }

        return ResponseEntity.ok("Checkout success");
    }

    // ✅ Mock CCA
    private boolean callCCA(String creditCardNumber) {
        return creditCardNumber.equals("1234");
    }
}