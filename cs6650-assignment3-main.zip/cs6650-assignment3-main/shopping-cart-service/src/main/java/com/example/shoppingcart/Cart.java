package com.example.shoppingcart;

import java.util.HashMap;
import java.util.Map;

public class Cart {

    private String cartId;
    private Map<String, Integer> items;

    public Cart(String cartId) {
        this.cartId = cartId;
        this.items = new HashMap<>();
    }

    public String getCartId() {
        return cartId;
    }

    public Map<String, Integer> getItems() {
        return items;
    }

    public void addItem(String productId, int quantity) {
        items.put(productId, items.getOrDefault(productId, 0) + quantity);
    }
}