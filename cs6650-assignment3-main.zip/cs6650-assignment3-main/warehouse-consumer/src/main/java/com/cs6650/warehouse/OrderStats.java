package com.cs6650.warehouse;

import com.cs6650.warehouse.model.OrderMessage;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Thread-safe statistics store shared by all consumer threads.
 *
 * Data structures match TEAM_GUIDE.md contract exactly:
 *
 *   private static final AtomicInteger totalOrders = new AtomicInteger(0);
 *   private static final ConcurrentHashMap<Integer, AtomicInteger> productQuantities = new ConcurrentHashMap<>();
 */
public class OrderStats {

    /** Total number of orders received. */
    private static final AtomicInteger totalOrders = new AtomicInteger(0);

    /**
     * Per-product total quantity ordered.
     * Key:   product_id (Integer)
     * Value: cumulative quantity (AtomicInteger) — thread-safe increment without locking
     */
    private static final ConcurrentHashMap<Integer, AtomicInteger> productQuantities = new ConcurrentHashMap<>();

    /**
     * Record one processed order.
     * Called by each worker thread after ack-ing a message.
     */
    public void recordOrder(java.util.List<OrderMessage.OrderItem> items) {
        totalOrders.incrementAndGet();

        if (items == null) return;
        for (OrderMessage.OrderItem item : items) {
            // computeIfAbsent is atomic: creates a new AtomicInteger(0) only if key is absent,
            // then addAndGet adds the quantity. Safe for concurrent access.
            productQuantities
                .computeIfAbsent(item.getProductId(), k -> new AtomicInteger(0))
                .addAndGet(item.getQuantity());
        }
    }

    public int getTotalOrders() {
        return totalOrders.get();
    }

    public ConcurrentHashMap<Integer, AtomicInteger> getProductQuantities() {
        return productQuantities;
    }
}
