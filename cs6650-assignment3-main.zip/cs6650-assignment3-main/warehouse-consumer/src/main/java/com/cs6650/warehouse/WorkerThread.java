package com.cs6650.warehouse;

import com.cs6650.warehouse.model.OrderMessage;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.DeliverCallback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.StandardCharsets;

/**
 * A single consumer worker thread, modeled directly after professor's RecvMT.java.
 *
 * Key design decisions (matching RecvMT pattern):
 *  1. Implements Runnable (not extends Thread) — same as RecvMT's anonymous Runnable.
 *  2. Uses DeliverCallback lambda — same style as RecvMT, not DefaultConsumer.
 *  3. Each thread creates its own Channel inside run() — channels are NOT thread-safe.
 *  4. basicQos(1) — max one unacked message per consumer, same as RecvMT.
 *  5. ACK order: basicAck FIRST, then update stats — matches RecvMT's ack-before-print order.
 *     Rationale: stats updates (ConcurrentHashMap/AtomicInteger) never fail, so acking
 *     first is safe and keeps us aligned with the professor's reference implementation.
 */
public class WorkerThread implements Runnable {

    private static final Logger log = LoggerFactory.getLogger(WorkerThread.class);

    private final int threadId;
    private final Connection connection;   // shared across threads — Connection IS thread-safe
    private final String queueName;
    private final OrderStats stats;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public WorkerThread(int threadId, Connection connection, String queueName, OrderStats stats) {
        this.threadId = threadId;
        this.connection = connection;
        this.queueName = queueName;
        this.stats = stats;
    }

    @Override
    public void run() {
        try {
            // Each thread gets its own channel — identical to RecvMT pattern
            final Channel channel = connection.createChannel();

            // durable=true: queue survives broker restart
            channel.queueDeclare(queueName, /*durable=*/true, /*exclusive=*/false,
                    /*autoDelete=*/false, null);

            // Max 1 unacked message per consumer — same as RecvMT
            channel.basicQos(1);

            log.info("[Worker-{}] Waiting for messages on '{}'", threadId, queueName);

            // DeliverCallback lambda — same style as RecvMT.java
            DeliverCallback deliverCallback = (consumerTag, delivery) -> {
                String json = new String(delivery.getBody(), StandardCharsets.UTF_8);

                // ACK first, then process — matches RecvMT's ack-before-print order.
                // Stats operations (AtomicInteger / ConcurrentHashMap) are infallible,
                // so this ordering is safe and consistent with the reference code.
                channel.basicAck(delivery.getEnvelope().getDeliveryTag(), /*multiple=*/false);

                try {
                    OrderMessage order = objectMapper.readValue(json, OrderMessage.class);
                    stats.recordOrder(order.getItems());
                    log.debug("[Worker-{}] Processed order_id={}", threadId, order.getOrderId());
                } catch (Exception e) {
                    // JSON parse failure: message already acked, just log and move on.
                    // (Same as RecvMT — no nack/requeue on bad messages.)
                    log.warn("[Worker-{}] Could not parse message, skipping: {}", threadId, e.getMessage());
                }
            };

            // autoAck=false — we ack manually inside the callback above
            channel.basicConsume(queueName, /*autoAck=*/false, deliverCallback, consumerTag -> {});

            // Block this thread — the DeliverCallback fires on the channel's dispatch thread.
            // This mirrors RecvMT which also just lets the threads block after basicConsume.
            while (channel.isOpen()) {
                Thread.sleep(500);
            }

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            log.info("[Worker-{}] Interrupted, exiting.", threadId);
        } catch (Exception e) {
            log.error("[Worker-{}] Fatal error: {}", threadId, e.getMessage(), e);
        }
    }
}

