package com.cs6650.warehouse;

import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Main entry point for the Warehouse Consumer.
 *
 * Thread spawning pattern matches professor's RecvMT.java:
 *   WorkerThread runnable = new WorkerThread(...);
 *   Thread t = new Thread(runnable, "warehouse-worker-N");
 *   t.start();
 *
 * Configuration via environment variables:
 *   RABBITMQ_HOST, RABBITMQ_PORT, RABBITMQ_USER, RABBITMQ_PASS,
 *   RABBITMQ_VHOST, QUEUE_NAME, NUM_CONSUMER_THREADS
 */
public class WarehouseConsumer {

    private static final Logger log = LoggerFactory.getLogger(WarehouseConsumer.class);

    public static void main(String[] args) throws Exception {

        // ── Read configuration ─────────────────────────────────────────────────
        String host       = getEnv("RABBITMQ_HOST",           "localhost");
        int    port       = getEnvInt("RABBITMQ_PORT",        5672);
        String user       = getEnv("RABBITMQ_USER",           "guest");
        String pass       = getEnv("RABBITMQ_PASS",           "guest");
        String vhost      = getEnv("RABBITMQ_VHOST",          "/");
        String queueName  = getEnv("QUEUE_NAME",              "warehouse_queue");
        int    numThreads = getEnvInt("NUM_CONSUMER_THREADS", 10);

        log.info("=== Warehouse Consumer starting ===");
        log.info("  Broker:  {}:{}{}", host, port, vhost);
        log.info("  Queue:   {}", queueName);
        log.info("  Threads: {}", numThreads);

        // ── Shared statistics (thread-safe) ────────────────────────────────────
        OrderStats stats = new OrderStats();

        // ── Single shared Connection — Connection IS thread-safe ───────────────
        // Each WorkerThread creates its own Channel inside run(),
        // exactly as in RecvMT.java: final Channel channel = connection.createChannel()
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost(host);
        factory.setPort(port);
        factory.setUsername(user);
        factory.setPassword(pass);
        factory.setVirtualHost(vhost);
        factory.setAutomaticRecoveryEnabled(true);
        factory.setNetworkRecoveryInterval(3000);

        final Connection connection = factory.newConnection("warehouse-consumer");
        log.info("Connected to RabbitMQ at {}:{}", host, port);

        // ── Spawn worker threads — RecvMT.java pattern ────────────────────────
        // RecvMT:  Thread recv1 = new Thread(runnable); recv1.start();
        // We do the same in a loop, keeping handles for join() in shutdown hook.
        List<Thread> threads = new ArrayList<>(numThreads);
        for (int i = 0; i < numThreads; i++) {
            WorkerThread worker = new WorkerThread(i + 1, connection, queueName, stats);
            Thread t = new Thread(worker, "warehouse-worker-" + (i + 1));
            threads.add(t);
            t.start();
        }
        log.info("Started {} consumer threads.", numThreads);
        log.info("[*] Waiting for messages. To exit press CTRL+C");

        // ── Shutdown Hook ──────────────────────────────────────────────────────
        // Fires on Ctrl+C or `docker stop` (SIGTERM).
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            log.info("=== Shutdown signal received ===");

            // Interrupt all worker threads → exits their sleep() loops
            for (Thread t : threads) {
                t.interrupt();
            }

            // Wait for each worker to drain its current in-flight ack
            for (Thread t : threads) {
                try {
                    t.join(5000);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }

            // Close the shared connection
            try {
                if (connection.isOpen()) {
                    connection.close();
                    log.info("RabbitMQ connection closed.");
                }
            } catch (Exception e) {
                log.warn("Error closing connection: {}", e.getMessage());
            }

            // *** Required by assignment: print total number of orders on shutdown ***
            System.out.println("====================================");
            System.out.println("Total Orders Processed: " + stats.getTotalOrders());
            System.out.println("Per-Product Quantities:");
            stats.getProductQuantities().entrySet().stream()
                    .sorted(Map.Entry.comparingByKey())
                    .forEach(entry -> System.out.println("  ProductID " + entry.getKey() + " -> " + entry.getValue().get()));
            System.out.println("====================================");

        }, "shutdown-hook"));

        // ── Keep main thread alive until all workers exit ──────────────────────
        for (Thread t : threads) {
            t.join();
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private static String getEnv(String key, String defaultValue) {
        String val = System.getenv(key);
        return (val != null && !val.isBlank()) ? val.trim() : defaultValue;
    }

    private static int getEnvInt(String key, int defaultValue) {
        String val = System.getenv(key);
        if (val != null && !val.isBlank()) {
            try {
                return Integer.parseInt(val.trim());
            } catch (NumberFormatException e) {
                log.warn("Invalid value for {}: '{}', using default {}", key, val, defaultValue);
            }
        }
        return defaultValue;
    }
}
