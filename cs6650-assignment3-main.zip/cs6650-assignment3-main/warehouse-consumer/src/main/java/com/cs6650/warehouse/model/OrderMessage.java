package com.cs6650.warehouse.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * Matches the message format agreed upon with ShoppingCart service:
 * {
 *   "order_id": "5234224c-7d51-4b8e-b357-a445d9598d3a",
 *   "items": [
 *     {"product_id": 1, "quantity": 2},
 *     ...
 *   ]
 * }
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class OrderMessage {

    @JsonProperty("order_id")
    private String orderId;

    @JsonProperty("items")
    private List<OrderItem> items;

    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }

    public List<OrderItem> getItems() { return items; }
    public void setItems(List<OrderItem> items) { this.items = items; }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class OrderItem {
        @JsonProperty("product_id")
        private int productId;

        @JsonProperty("quantity")
        private int quantity;

        public int getProductId() { return productId; }
        public void setProductId(int productId) { this.productId = productId; }

        public int getQuantity() { return quantity; }
        public void setQuantity(int quantity) { this.quantity = quantity; }
    }
}
