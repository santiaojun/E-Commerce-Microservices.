package com.cs6650.warehouse.model;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class OrderMessageTest {

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Test
    void shouldParseUuidOrderIdFromShoppingCartMessage() throws Exception {
        String json = """
                {
                  "order_id": "5234224c-7d51-4b8e-b357-a445d9598d3a",
                  "items": [
                    {"product_id": 1, "quantity": 2},
                    {"product_id": 3, "quantity": 5}
                  ]
                }
                """;

        OrderMessage msg = objectMapper.readValue(json, OrderMessage.class);

        assertEquals("5234224c-7d51-4b8e-b357-a445d9598d3a", msg.getOrderId());
        assertEquals(2, msg.getItems().size());
        assertEquals(1, msg.getItems().get(0).getProductId());
        assertEquals(2, msg.getItems().get(0).getQuantity());
        assertEquals(3, msg.getItems().get(1).getProductId());
        assertEquals(5, msg.getItems().get(1).getQuantity());
    }

    @Test
    void shouldAlsoParseNumericOrderId() throws Exception {
        String json = """
                {
                  "order_id": 12345,
                  "items": [{"product_id": 9, "quantity": 1}]
                }
                """;

        OrderMessage msg = objectMapper.readValue(json, OrderMessage.class);

        assertEquals("12345", msg.getOrderId());
        assertEquals(1, msg.getItems().size());
        assertEquals(9, msg.getItems().get(0).getProductId());
        assertEquals(1, msg.getItems().get(0).getQuantity());
    }
}
