package com.cs6650.warehouse;

import com.cs6650.warehouse.model.OrderMessage;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class OrderStatsTest {

    @Test
    void shouldCountTotalOrdersAndProductQuantities() {
        OrderStats stats = new OrderStats();

        OrderMessage.OrderItem first = new OrderMessage.OrderItem();
        first.setProductId(1);
        first.setQuantity(2);

        OrderMessage.OrderItem second = new OrderMessage.OrderItem();
        second.setProductId(2);
        second.setQuantity(3);

        OrderMessage.OrderItem third = new OrderMessage.OrderItem();
        third.setProductId(1);
        third.setQuantity(4);

        stats.recordOrder(List.of(first, second));
        stats.recordOrder(List.of(third));

        assertEquals(2, stats.getTotalOrders());
        assertEquals(6, stats.getProductQuantities().get(1).get());
        assertEquals(3, stats.getProductQuantities().get(2).get());
    }
}
